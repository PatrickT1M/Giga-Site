function duvida() {
    var url = "https://wa.me/+551938122626" 

    window.open(url, '_blank').focus();
}

function ingles() {
    var ingles = "Oi, me interessei pelo curso de INGLÊS. Poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        ingles;

    window.open(url, '_blank').focus();
}

function guitarra() {
    var guitarra = "Oi, gostaria de aprender a tocar Guitarra, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        guitarra;

    window.open(url, '_blank').focus();
}

function kids() {
    var kids = "Oi, me interessei pelo curso KIDS, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        kids;

    window.open(url, '_blank').focus();
}

function logistica() {
    var logistica = "Oi, me interessei pelo curso de LOGÍSTICA, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        logistica;

    window.open(url, '_blank').focus();
}

function bateria() {
    var bateria = "Oi, gostaria de aprender a tocar Bateria, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        bateria;

    window.open(url, '_blank').focus();
}
function violao() {
    var viola = "Oi, gostaria de aprender a tocar Violão, poderia me explicar melho?"

    var url = "https://wa.me/+551938122626?text=" +
        viola;

    window.open(url, '_blank').focus();
}
function baixo() {
    var baixo = "Oi, gostaria de aprender a tocar Baixo, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        baixo;

    window.open(url, '_blank').focus();
}
function teclado() {
    var teclado = "Oi, gostaria de aprender a tocar Teclado, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        teclado;

    window.open(url, '_blank').focus();
}
function piano() {
    var piano = "Oi, gostaria de aprender a tocar Piano, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        piano;

    window.open(url, '_blank').focus();
}

function robo() {
    var robo = "Oi, me interresei pelo curso de Robótica, poderia me explicar melhor?"
    var url = "https://wa.me/+551938122626?text=" + robo
    window.open(url, '_blank').focus();
}

function adm() {
    var adm = "Oi, me interessei pelo curso de Administração, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        adm;

    window.open(url, '_blank').focus();
}

function web() {
    var web = "Oi, me interessei pelo curso de WEB DEVELOPER, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        web;

    window.open(url, '_blank').focus();
}

function apps() {
    var apps = "Oi, me interessei pelo curso de Desenvolvedor de Apps, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        apps;

    window.open(url, '_blank').focus();
}

function cad() {
    var cad = "Oi, me interessei pelo curso de Auto Cad, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        cad;

    window.open(url, '_blank').focus();
}

function design() {
    var design = "Oi, me interessei pelo curso de Design, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        design;

    window.open(url, '_blank').focus();
}

function idade() {
    var idade = "Oi, me interessei pelo curso de Melhor Idade, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        idade;

    window.open(url, '_blank').focus();
}

function info() {
    var info = "Oi, me interessei pelo curso de Informática, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        info;

    window.open(url, '_blank').focus();
}

function hardware() {
    var hardware = "Oi, me interessei pelo curso de Hardware e Redes, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        hardware;

    window.open(url, '_blank').focus();
}


function op_info() {
    var op_info = "Oi, me interessei pelo curso de Operador de Informática, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        op_info;

    window.open(url, '_blank').focus();
}

function op_info_master() {
    var op_info_master = "Oi, me interessei pelo curso de Operador de Informática Master, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        op_info_master;

    window.open(url, '_blank').focus();
}

function cursos1() {

    var url = "todos_cursos.html"
    window.location.href = url;
    
}

function abrir_info() {

    var url = "cursos/curso_info.html"
    window.location.href = url;
    
}

function abrir_adm() {

    var url = "cursos/curso_adm.html"
    window.location.href = url;
    
}

function abrir_musica() {

    var url = "cursos/curso_musi.html"
    window.location.href = url;
    
}

function musi(){
    var musi = "Oi, me interessei pelas aulas de MÚSICAS, poderia me explicar melhor?"
    var url = "https://wa.me/+551938122626?text=" + musi;
    window.open(url, '_blank').focus();

}

function abrir_ingles() {

    var url = "cursos/curso_ingles.html"
    window.location.href = url;
    
}

function excel() {
    var excel = "Oi, me interessei pelo curso de Excel, poderia me explicar melhor?"

    var url = "https://wa.me/+551938122626?text=" +
        excel;

    window.open(url, '_blank').focus();
}