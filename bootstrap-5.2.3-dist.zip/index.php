<!doctype html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="description" content="A Giga Cursos oferece o que há de melhor em cursos profissionalizantes aos nossos parceiros e colaboradores, visando sempre o crescimento e aprendizagem da população, levando a capacitação das pessoas para o mercado de trabalho, que a cada dia se torna mais competitivo. Nosso Lema Engajar, Motivar e Incentivar">
    <meta name="author" content="Patrick Moreira Costa">
    <link rel="shortcut icon" href="images/logo_nova_sem_fundo.png" type="image/x-icon">

    <title>Giga Cursos</title>

    <!-- ARQUIVOS CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="css/css.css">

    <link href="css/bootstrap-icons.css" rel="stylesheet">

    <link href="css/templatemo-kind-heart-charity.css" rel="stylesheet">

    <!--



TemplateMo 581 Kind Heart Charity

https://templatemo.com/tm-581-kind-heart-charity

-->

</head>

<body id="corpo-site">

    <header class="site-header">
        <div class="container">
            <div class="row">

                <div class="col-lg-8 col-12 d-flex flex-wrap">
                    <p class="d-flex me-4 mb-0">
                        <i class="bi-geo-alt me-2"></i>
                        Rua 9 de Julho, 121, Bela-Vista, Cosmópolis-SP
                    </p>

                    <p class="d-flex mb-0">
                        <i class="bi-envelope me-2"></i>

                        <a href="mailto:admgigacursos@gmail.com">
                            admgigacursos@gmail.com
                        </a>
                    </p>
                </div>

                <div class="col-lg-3 col-12 ms-auto d-lg-block d-none">
                    <ul class="social-icon">

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-instagram"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="#" class="social-icon-link bi-youtube"></a>
                        </li>

                        <li class="social-icon-item">
                            <a href="https://wa.me/+551938122626" class="social-icon-link bi-whatsapp"> <small>(19)
                                    3812-2626</small></a>
                        </li>
                    </ul>
                </div>


            </div>
        </div>
    </header>

    <nav class="navbar navbar-expand-lg bg-light shadow-lg">
        <div class="container">
            <a class="navbar-brand" href="http://gigaedu.com.br">
                <img src="images/logo_nova_sem_fundo.png" class="logo img-fluid" alt="Logo nova Giga">
                <span>
                    Giga
                    <small>Cursos Profissionalizantes</small>
                </span>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="index.php">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="index.php#sobre_localizacao" onclick="sobre();">Sobre</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link click-scroll" href="#informacoes_adicionais">Contato</a>
                    </li>

                    <!-- <li class="nav-item ms-3">
                        <a class="nav-link custom-btn custom-border-btn btn" href="news-detail.html">Notícias</a>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>

    <main>

        <section class="hero-section hero-section-full-height">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-lg-12 col-12 p-0">
                        <div id="hero-slide" class="carousel carousel-fade slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="images/slide/mexendo_pc.jpg" class="carousel-image img-fluid" alt="Pessoa mexendo no computador">

                                    <div class="carousel-caption d-flex flex-column justify-content-end">
                                        <h1>Ensino</h1>

                                        <p>Venha aprender conosco!</p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <img src="images/slide/pulando_alegria.jpg" class="carousel-image img-fluid" alt="Logo da giga">

                                    <div class="carousel-caption d-flex flex-column justify-content-end">
                                        <h1>Sonhos</h1>

                                        <p>Venha realizar seus sonhos!</p>
                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <img src="images/slide/fachada.jpg" class="carousel-image img-fluid" alt="Fachada da escola giga">

                                    <div class="carousel-caption d-flex flex-column justify-content-end">
                                        <h1>GIGA</h1>

                                        <p>Venha ser gigante!</p>
                                    </div>
                                </div>
                            </div>

                            <button class="carousel-control-prev" type="button" data-bs-target="#hero-slide" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>

                            <button class="carousel-control-next" type="button" data-bs-target="#hero-slide" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </section>


        <section class="section-padding" id="cursos">
            <div class="container">
                <div class="row">

                    <div class="col-lg-10 col-12 text-center mx-auto">
                        <h2 class="mb-5">Bem-Vindo a Giga</h2>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a onclick="abrir_info();" style="cursor: pointer;" class="d-block">
                                <img src="images/icons/pc.png" class="featured-block-image img-fluid" alt="Icone de um computador">

                                <p class="featured-block-text"><strong>INFORMÁTICA</strong></p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a onclick="abrir_adm();" style="cursor:pointer;" class="d-block">
                                <img src="images/icons/adm.png" class="featured-block-image img-fluid" alt="Icone de um calendário">

                                <p class="featured-block-text"><strong>ADMINISTRAÇÃO</strong></p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-4 mb-lg-0 mb-md-4">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a onclick="abrir_musica();" style="cursor:pointer;" class="d-block">
                                <img src="images/icons/musica.png" class="featured-block-image img-fluid" alt="Icone de notas musicais">

                                <p class="featured-block-text"><strong>MÚSICA</strong></p>
                            </a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb- mb-lg-0">
                        <div class="featured-block d-flex justify-content-center align-items-center">
                            <a onclick="abrir_ingles();" style="cursor:pointer;" class="d-block">
                                <img src="images/icons/ingles.png" class="featured-block-image img-fluid" alt="Icone da bandeira do Reino Unido">

                                <p class="featured-block-text"><strong>INGLÊS</strong></p>
                            </a>
                        </div>
                    </div>

                    <button type="submit" class="interessei" onclick="cursos1();">Ver Todos os Cursos</button>

                </div>
            </div>
        </section>

        <section class="section-padding section-bg" id="sobre_localizacao">
            <div class="container">
                <div class="row">


                    <div class="col-lg-6 col-12 mb-5 mb-lg-0">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d3682.147179673019!2d-47.20015108314115!3d-22.648300493811938!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x94c8923fe75bb433%3A0xea8dbb49e4a5a1c2!2sAv.%209%20de%20Julho%2C%20121%20-%20Jardim%20Bela%20Vista%2C%20Cosm%C3%B3polis%20-%20SP%2C%2013150-150!3m2!1d-22.6483055!2d-47.1959239!5e0!3m2!1spt-BR!2sbr!4v1670628525330!5m2!1spt-BR!2sbr" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>

                    <div class="col-lg-6 col-12">
                        <div class="custom-text-box">
                            <h2 class="mb-2">Giga</h2>

                            <h5 class="mb-2">Localização do Giga</h5>

                            <p class="mb-0">Giga uma escola capacitada em atender você e sua família. Somos uma equipe
                                que queremos proporcionar um ótimo atendimento, caminhando junto ao seu futuro. Venha
                                ser Gigante!</p>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 col-md-2 col-12">
                                <div class="custom-text-box mb-lg-0">
                                    <h5 class="mb-3">Nossa missão</h5>

                                    <p>visar sempre o crescimento e aprendizagem da população, levando a capacitação das pessoas para o mercado de trabalho, que a cada dia se torna mais competitivo.</p>

                                    <!-- <ul class="custom-list mt-0">
                                        <li class="custom-list-item d-flex">
                                            <i class="bi-check custom-text-box-icon me-2"></i>
                                            Venha ser
                                        </li>

                                        <li class="custom-list-item d-flex">
                                            <i class="bi-check custom-text-box-icon me-2"></i>
                                            Gigante
                                        </li>
                                    </ul> -->
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="custom-text-box d-flex flex-wrap d-lg-block mb-lg-0">
                                    <div class="counter-thumb">
                                        <span class="counter-text">Desde</span>
                                        <div class="d-flex">
                                            <span class="counter-number" data-from="1" data-to="2002" data-speed="1102"></span>
                                            <span class="counter-number-text"></span>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>




        <section class="cta-section section-padding section-bg">
            <div class="container">
                <div class="row justify-content-center align-items-center">

                    <div class="col-lg-5 col-12 ms-auto">
                        <h2 class="mb-0">Faça a diferença. <br> Seja Gigante.</h2>
                    </div>

                    <div class="col-lg-5 col-12">
                        <a href="#cursos" class="me-4">Nossos cursos</a>

                        <a href="#fale_conosco" class="custom-btn btn smoothscroll">Novidades</a>
                    </div>

                </div>
            </div>
        </section>


        <section class="section-padding" id="">
            <div class="container">
                <div class="row">

                    <div class="col-lg-12 col-12 text-center mb-4">
                        <h2>Nossos Cursos</h2>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="custom-block-wrap">
                            <img src="images/guitarra.jpg" class="custom-block-image img-fluid" alt="Imagens de guitarras penduradas">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">Guitarra</h5>
                                    <h6>Por que aprender MÚSICA?</h6>
                                    <p>Porque ela é capaz de acionar inúmeras áreas do cérebro e aumentar as sinapses,
                                        ativando pontos de atenção, raciocínio e memória.</p>

                                    <div class="progress mt-4">
                                        <div class="progress-bar w-75" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>

                                <a href="#cursos" class="custom-btn btn" onclick="guitar();">Saiba mais</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12 mb-4 mb-lg-0">
                        <div class="custom-block-wrap">
                            <img src="images/ingles.jpg" class="custom-block-image img-fluid" alt="Menina em frente a louça, escrito em inglês">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">Inglês</h5>
                                    <h6>Por que aprender INGLÊS?</h6>
                                    <p>Porque se trata do idioma mais falado no mundo. Sua importância se revela
                                        especialmente no mercado de trabalho.</p>

                                    <div class="progress mt-4">
                                        <div class="progress-bar w-100" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>

                                <a href="#section-cursos" class="custom-btn btn" onclick="ingles();">Saiba mais</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="custom-block-wrap">
                            <img src="images/microsoft-excel-1.jpg" class="custom-block-image img-fluid" alt="Imagem no Microsoft Excel">

                            <div class="custom-block">
                                <div class="custom-block-body">
                                    <h5 class="mb-3">Excel</h5>
                                    <h6>Por que aprender EXCEL?</h6>
                                    <p>Porque o excel é uma das ferramentas mais versáteis da Microsoft e permite que
                                        empresas automatizem seu trabalho.
                                    </p>

                                    <div class="progress mt-4">
                                        <div class="progress-bar w-50" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>

                                <a href="#section-cursos" class="custom-btn btn" onclick="excel();">Saiba mais</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="contact-section section-padding" id="section_6">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-12 ms-auto mb-5 mb-lg-0">
                        <div class="contact-info-wrap">
                            <h2>Entre em Contato</h2>

                            <div class="contact-image-wrap d-flex flex-wrap">
                                <img src="images/admgiga.gif" class="img-fluid avatar-image" alt="logo_giga_adm">

                                <div class="d-flex flex-column justify-content-center ms-3">
                                    <p class="mb-0">Adm Giga Cursos</p>
                                    <p class="mb-0"><strong>Jéssica e Natalia</strong></p>
                                </div>
                            </div>

                            <div class="contact-info">
                                <h5 class="mb-3">Informações de Contato</h5>

                                <p class="d-flex mb-2">
                                    <i class="bi-geo-alt me-2"></i>
                                    Rua 9 de Julho, 121, Bela-Vista, Cosmópolis-SP
                                </p>

                                <p class="d-flex mb-2">
                                    <i class="bi-telephone me-2"></i>

                                    <a href="https://wa.me/+551938122626">
                                        (19) 3812-2626
                                    </a>
                                </p>

                                <p class="d-flex">
                                    <i class="bi-envelope me-2"></i>

                                    <a href="mailto:admgigacursos@gmail.com">
                                        admgigacursos@gmail.com
                                    </a>
                                </p>

                                <a href="https://wa.me/+551938122626" class="custom-btn btn mt-3">Fale Conosco</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-5 col-12 mx-auto">
                        <form class="custom-form contact-form" method="post" action="#" role="form">
                            <h2>Formulário de Contato</h2>

                            <p class="mb-4">Ou nos envie um e-mail
                                <a href="mailto:admgigacursos@gmail.com">admgigacursos@gmail.com</a>
                            </p>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-12">
                                    <input type="text" name="primeiro_nome" id="nome" class="form-control" placeholder="Primeiro nome" required>
                                </div>

                                <div class="col-lg-6 col-md-6 col-12">
                                    <input type="text" name="sobrenome" id="sobrenome" class="form-control" placeholder="Sobrenome" required>
                                </div>
                            </div>
                            <p class="mb-4">
                                Selecione um Curso
                            </p>
                            <select class="form-control" id="curso" name="cursos" required>

                                <option value="Informática">Informática</option>
                                <option value="Inglês">Inglês</option>
                                <option value="Música">Música</option>
                                <option value="Administração">Administração</option>

                            </select>

                            <textarea name="mensagem" rows="5" class="form-control" id="mensagem" placeholder="Mensagem Opcional"></textarea>

                            <input type="submit" class="custom-btn btn" onclick="zap()" value="Enviar">
                        </form>
                    </div>

                </div>
            </div>
        </section>
    </main>



    <footer class="site-footer" id="informacoes_adicionais">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12 mb-4">
                    <img src="images/logo_nova_sem_fundo.png" class="logo img-fluid" alt="Logo nova da giga">
                </div>

                <div class="col-lg-4 col-md-6 col-12 mx-auto">
                    <h5 class="site-footer-title mb-3">Contatos para informação</h5>

                    <p class="text-white d-flex mb-2">
                        <i class="bi-telephone me-2"></i>

                        <a href="https://wa.me/+551938122626" class="site-footer-link">
                            (19) 3812-2626
                        </a>
                    </p>

                    <p class="text-white d-flex">
                        <i class="bi-envelope me-2"></i>

                        <a href="mailto:admgigacursos@gmail.com" class="site-footer-link">
                            admgigacursos@gmail.com
                        </a>
                    </p>

                    <p class="text-white d-flex mt-3">
                        <i class="bi-geo-alt me-2"></i>
                        Rua 9 de Julho 121, Bela-Vista, Cosmópolis-SP
                    </p>

                    <a href="#cursos" class="custom-btn btn mt-3">Cursos</a>
                </div>
            </div>
        </div>

        <div class="site-footer-bottom">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-7 col-12">
                        <p class="copyright-text mb-0">Desenvolvido por <span class="feito">Patrick Moreira
                                Costa</span>
                            para <a href="index.html"> Giga</a> Cursos.
                        </p>
                    </div>

                    <div class="col-lg-6 col-md-5 col-12 d-flex justify-content-center align-items-center mx-auto">
                        <ul class="social-icon">

                            <li class="social-icon-item">
                                <a href="https://www.instagram.com/gigaeduoficial/" class="social-icon-link bi-instagram"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://wa.me/+551938122626" class="social-icon-link bi-whatsapp"></a>
                            </li>

                            <li class="social-icon-item">
                                <a href="https://www.youtube.com/@cursosgiga2339" class="social-icon-link bi-youtube"></a>
                            </li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </footer>

    <!-- ARQUIVOS JAVASCRIPT -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/click-scroll.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/enviar.js"></script>

    <script>
        function zap() {
            var nome = document.getElementById("nome").value;
            var sobrenome = document.getElementById("sobrenome").value;
            var mensagem = document.getElementById("mensagem").value;
            var cursos = document.getElementById("curso").value;

            if (nome.trim() === "" || sobrenome.trim() === "" || mensagem.trim() === "") {
                alert("Preencha todas as informações antes de enviar")
                return;
            }

            var url = "https://wa.me/+551938122626?text=" +
                "Oi, me chamo " + nome + "%0a" + sobrenome + ", gostaria de saber mais sobre o curso de" + "%0a" + cursos + "." + "%0a%0a" + mensagem;

            window.open(url, '_blank').focus();
        }
    </script>
</body>

</html>